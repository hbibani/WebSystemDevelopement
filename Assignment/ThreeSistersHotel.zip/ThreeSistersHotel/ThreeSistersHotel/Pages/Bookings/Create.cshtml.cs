﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using ThreeSistersHotel.Data;
using ThreeSistersHotel.Models;

namespace ThreeSistersHotel.Pages.Bookings
{
    [Authorize(Roles = "admin")]
    public class CreateModel : PageModel
    {
        private readonly ThreeSistersHotel.Data.ApplicationDbContext _context;

        public CreateModel(ThreeSistersHotel.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["CustomerEmail"] = new SelectList(_context.Customer, "Email", "FullName");
            ViewData["RoomID"] = new SelectList(_context.Room, "ID", "ID");
            return Page();
        }

        [BindProperty]
        public Booking BookingInput { get; set; }
        public IList<Booking> BookingCheck { get; set; }
        public Room RoomOutput { get; set; }

        public Booking booking { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            ViewData["CustomerEmail"] = new SelectList(_context.Customer, "Email", "FullName");
            ViewData["RoomID"] = new SelectList(_context.Room, "ID", "ID");

            if (!ModelState.IsValid)
            {
                return Page();
            }

            int daysDiff = (BookingInput.CheckOut - BookingInput.CheckIn).Days;

            if (daysDiff <= 0)
            {
                ViewData["DaysDiff"] = 1;
                return Page();
            }

            RoomOutput = await _context.Room.FirstOrDefaultAsync(r => r.ID == BookingInput.RoomID);
            var roomID = new SqliteParameter("rID", BookingInput.RoomID);
            var cOutB = new SqliteParameter("checkOutB", BookingInput.CheckOut);
            var cInB = new SqliteParameter("checkInB", BookingInput.CheckIn);

            //SELECT * FROM ROOM WHERE BOOKINGA.CheckIN 
            IQueryable<Booking> Bookings = _context.Booking.FromSqlRaw("SELECT [Booking].* FROM [Booking] inner join [Room] on [Room].ID = [Booking].RoomID WHERE [Booking].RoomID = @rID AND ([Booking].CheckIn  < @checkOutB AND @checkInB < [Booking].CheckOut)", roomID, cOutB, cInB);
            BookingCheck = await Bookings.ToListAsync();

            if (BookingCheck.Count == 0)
            {
                booking = new Booking();
                booking.RoomID = BookingInput.RoomID;
                booking.CustomerEmail = BookingInput.CustomerEmail;
                booking.CheckIn = BookingInput.CheckIn;
                booking.CheckOut = BookingInput.CheckOut;
                booking.Cost = BookingInput.Cost;
                _context.Booking.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToPage("./ManageBookings");
            }

            return Page();
        }
    }
}
