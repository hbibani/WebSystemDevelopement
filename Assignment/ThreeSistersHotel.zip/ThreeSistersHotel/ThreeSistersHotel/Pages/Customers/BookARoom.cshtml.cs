using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ThreeSistersHotel.Models;
using Microsoft.Data.Sqlite;
using ThreeSistersHotel.Pages.Bookings;
using Microsoft.AspNetCore.Authorization;

namespace ThreeSistersHotel.Pages.Customers
{
    [Authorize(Roles = "customers")]
    public class BookARoomModel : PageModel
    {
        private readonly ThreeSistersHotel.Data.ApplicationDbContext _context;

        public BookARoomModel(ThreeSistersHotel.Data.ApplicationDbContext context)
        {
            _context = context;
        }


        [BindProperty]
        public MakeABooking BookingInput { get; set; }

        public IList<Booking> BookingCheck{ get; set;}
        public Room RoomOutput { get; set; }

        public Booking booking { get; set; }

        public IActionResult OnGet()
        {
            ViewData["RoomID"] = new SelectList(_context.Room, "ID", "ID");
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
           ViewData["RoomID"] = new SelectList(_context.Room, "ID", "ID");

           if (!ModelState.IsValid)
            {
                return Page();
            }


            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;
            Customer customer = await _context.Customer.FirstOrDefaultAsync(m => m.Email == _email);

            //preapre variables for SQL execution
            RoomOutput = await _context.Room.FirstOrDefaultAsync(r => r.ID == BookingInput.RoomID);
            var roomID = new SqliteParameter("rID", BookingInput.RoomID);
            var cOutB = new SqliteParameter("checkOutB", BookingInput.CheckOut);
            var cInB = new SqliteParameter("checkInB", BookingInput.CheckIn);

            DateTime today = DateTime.Today;

            //check for inconsistencies in date input
            int daysDiff = (BookingInput.CheckOut - BookingInput.CheckIn).Days;

            if (daysDiff <= 0)
            {
                ViewData["DaysDiff"] = 1;
                return Page();
            }

            int daysDiff2 = ( BookingInput.CheckIn - today).Days;

            if (daysDiff2 < 0)
            {
                ViewData["DaysDiff2"] = 1;
                return Page();
            }

            //make query
            IQueryable<Booking> Bookings = _context.Booking.FromSqlRaw("SELECT [Booking].* FROM [Booking] inner join [Room] on [Room].ID = [Booking].RoomID WHERE [Booking].RoomID = @rID AND ([Booking].CheckIn  < @checkOutB AND @checkInB < [Booking].CheckOut)", roomID, cOutB, cInB);
            BookingCheck = await Bookings.ToListAsync();

            //if no bookings then perform update
            if (BookingCheck.Count == 0)
            {
                booking = new Booking();
                booking.RoomID = BookingInput.RoomID;
                booking.CustomerEmail = _email;
                booking.CheckIn = BookingInput.CheckIn;
                booking.CheckOut = BookingInput.CheckOut;
                var theRoom = await _context.Room.FindAsync(BookingInput.RoomID);
                decimal cost = theRoom.Price * daysDiff;
                ViewData["Cost"] = cost;
                booking.Cost = cost;
                _context.Booking.Add(booking);

                //redirect if details of customer has not been entered
                try
                {
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {

                    return RedirectToPage("./MyDetails");
                }
                
            }

            return Page();
        }
    }
}
