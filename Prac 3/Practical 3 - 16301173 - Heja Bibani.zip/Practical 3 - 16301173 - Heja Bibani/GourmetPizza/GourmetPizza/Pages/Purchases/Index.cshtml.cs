﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using GourmetPizza.Data;
using GourmetPizza.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace GourmetPizza.Pages.Purchases
{
    [Authorize(Roles = "customers")]
    public class IndexModel : PageModel
    {
        private readonly GourmetPizza.Data.ApplicationDbContext _context;

        public IndexModel(GourmetPizza.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Purchase> Purchase { get;set; }


        public async Task OnGetAsync(string sortOrder)
        {

            if (String.IsNullOrEmpty(sortOrder))
            {
                // When the Index page is loaded for the first time, the sortOrder is empty.
                // By default, the movies should be displayed in the order of title_asc.
                sortOrder = "title_asc";
            }

            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;
            Customer customer = await _context.Customer.FirstOrDefaultAsync(m => m.Email == _email);

            var purchase = (IQueryable<Purchase>)_context.Purchase;

            switch (sortOrder)
            {
                case "title_asc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderBy(m => m.ThePizza);
                    break;
                case "title_desc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderByDescending(m => m.ThePizza);
                    break;
                case "price_asc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderBy(m => (double)m.TotalCost);
                    break;
                case "price_desc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderByDescending(m => (double)m.TotalCost);
                    break;
                case "count_asc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderBy(m => m.PizzaCount);
                    break;
                case "count_desc":
                    purchase = purchase.Include(p => p.TheCustomer).Include(p => p.ThePizza).Where(m => m.CustomerEmail == _email).OrderByDescending(m => m.PizzaCount);
                    break;
            }

            // Deciding the query string (sortOrder=xxx) to include in the heading links
            // for Title and Price respectively.
            // They specify the next display order if a heading link is clicked. 
            // Store them in ViewData dictionary to pass them to View.
            ViewData["NextTitleOrder"] = sortOrder != "title_asc" ? "title_asc" : "title_desc";
            ViewData["NextPriceOrder"] = sortOrder != "price_asc" ? "price_asc" : "price_desc";
            ViewData["NextCountOrder"] = sortOrder != "count_asc" ? "count_asc" : "count_desc";

            Purchase = await purchase.AsNoTracking().ToListAsync();

        }
    }
}
