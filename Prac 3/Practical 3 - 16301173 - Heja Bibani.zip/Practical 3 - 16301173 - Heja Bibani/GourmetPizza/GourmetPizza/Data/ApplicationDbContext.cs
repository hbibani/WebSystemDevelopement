﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GourmetPizza.Models;

namespace GourmetPizza.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<GourmetPizza.Models.Customer> Customer { get; set; }
        public DbSet<GourmetPizza.Models.Pizza> Pizza { get; set; }
        public DbSet<GourmetPizza.Models.Purchase> Purchase { get; set; }
    }
}
