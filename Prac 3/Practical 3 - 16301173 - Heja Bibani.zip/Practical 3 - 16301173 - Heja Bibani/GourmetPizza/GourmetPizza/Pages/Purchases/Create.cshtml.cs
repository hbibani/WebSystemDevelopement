﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using GourmetPizza.Data;
using GourmetPizza.Models;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace GourmetPizza.Pages.Purchases
{
    [Authorize(Roles = "customers")]
    public class CreateModel : PageModel
    {
        private readonly GourmetPizza.Data.ApplicationDbContext _context;

        public CreateModel(GourmetPizza.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["PizzaID"] = new SelectList(_context.Pizza, "ID", "PizzaName");
            return Page();
        }

        [BindProperty]
        public PurchaseViewModel PurchaseInput { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            ViewData["PizzaID"] = new SelectList(_context.Pizza, "ID", "PizzaName");

            if (!ModelState.IsValid)
            {
                return Page();
            }

            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;
            Purchase purchase = new Purchase();
            purchase.CustomerEmail = _email;
            purchase.PizzaID = PurchaseInput.PizzaID;
            purchase.PizzaCount = PurchaseInput.PizzaCount;
            var thePizza = await _context.Pizza.FindAsync(PurchaseInput.PizzaID);
            ViewData["PizzaName"] = thePizza.PizzaName;
            ViewData["PizzaNo"] = PurchaseInput.PizzaCount;
            purchase.TotalCost = thePizza.Price * PurchaseInput.PizzaCount;
            ViewData["TotalCost"] = purchase.TotalCost;
            _context.Purchase.Add(purchase);
            //redirect if details of customer has not been entered
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {

                return RedirectToPage("/Customers/MyDetails");
            }

            ViewData["Success"] = "true";
           

            return Page();
        }
    }
}
