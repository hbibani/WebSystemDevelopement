﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeSistersHotel.Models
{
    public class Room
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Each room must be on a level!")]

        [RegularExpression(@"^(G|1|2|3)$")]
        public string Level { get; set; }

        [Range(1, 3)]
        [RegularExpression(@"^(1|2|3)$")]
        [Display(Name = "Bed Count")]
        public int BedCount { get; set; }

        [Range(50, 300)]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        // Navigation properties
        public ICollection<Booking> TheBookings { get; set; }


    }
}
