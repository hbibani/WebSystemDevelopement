﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class PurchaseViewModel
    {
        [Required]
        public int PizzaID { get; set; }

        [Required]
        [Display(Name = "Number of Pizzas")]
        [Range(1, 80)]
        public int PizzaCount { get; set; }

    }
}
