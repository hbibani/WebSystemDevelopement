﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeSistersHotel.Models
{
    public class CustomerViewModel
    {
        [Required]
        [Display(Name = "Last Name")]
        [RegularExpression(@"[A-Z][a-z'-]{2,20}", ErrorMessage = "Please enter a valid last name with either letters, apostrophe or hyphen between 2 and 20 characters.")]
        public string SurName { get; set; }

        [Required]
        [Display(Name = "First Name")]
        [RegularExpression(@"[A-Z][a-z'-]{2,20}", ErrorMessage = "Please enter a valid first name with either letters, apostrophe or hyphen between 2 and 20 characters.")]
        public string GivenName { get; set; }

        [NotMapped] // not mapping this property to database, but exist in memory
        public string FullName => $"{GivenName} {SurName}";

        [DataType(DataType.PostalCode)]
        [Display(Name = "Postal Code")]
        [Required]
        [RegularExpression(@"^[0-9]{4}$", ErrorMessage = "Please enter a 4 digit number")]
        public string PostCode { get; set; }

    }
}
