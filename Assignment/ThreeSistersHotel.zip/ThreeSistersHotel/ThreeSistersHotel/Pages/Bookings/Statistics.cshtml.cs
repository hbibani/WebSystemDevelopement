using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ThreeSistersHotel.Models;

namespace ThreeSistersHotel.Pages.Bookings
{
    [Authorize(Roles = "admin")]
    public class StatisticsModel : PageModel
    {
        private readonly ThreeSistersHotel.Data.ApplicationDbContext _context;

        public StatisticsModel(ThreeSistersHotel.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<CustomerStatistic> CustomerStats { get; set; }
        public IList<BookingStatistic> BookingStats { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // divide the movies into groups by genre
            var customerGroups = _context.Customer.GroupBy(c => c.PostCode);
            var bookingGroups = _context.Booking.GroupBy(b => b.RoomID);

            // for each group, get its genre value and the number of movies in this group
            CustomerStats = await customerGroups.Select(c => new CustomerStatistic { PostCode = c.Key, PostCodeCount = c.Count() }).ToListAsync();
            BookingStats = await bookingGroups.Select(b => new BookingStatistic { Room = b.Key, BookingCount = b.Count() }).ToListAsync();
            return Page();
        }
    }
}
