﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeSistersHotel.Models
{
    public class SearchRoom
    {
        [Range(1, 3)]
        [RegularExpression(@"^(1|2|3)$")]
        [Display(Name = "Bed Count")]
        public int BedCount { get; set; }

        [DataType(DataType.Date)]
        [Required]
        [Display(Name = "Check in")]
        public DateTime CheckIn { get; set; }

        [DataType(DataType.Date)]
        [Required]
        [Display(Name = "Check out")]
        public DateTime CheckOut { get; set; }
    }
}
