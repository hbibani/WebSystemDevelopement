using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GourmetPizza.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace GourmetPizza.Pages.Pizzas
{
    public class PurchaseModel : PageModel
    {
        private readonly GourmetPizza.Data.GourmetPizzaContext _context;

        public PurchaseModel(GourmetPizza.Data.GourmetPizzaContext context)
        {
            _context = context;
        }

        public SelectList PizzaList { get; set; }

        [BindProperty(SupportsGet = true)]
        public PizzaPurchase PizzaPurchase { get; set; }



        public IActionResult OnGet()
        {
            // Obtain values for the <select> list in web form
            PizzaList = new SelectList(_context.Pizza, "PizzaName", "PizzaName");
            // Display the page
            return Page();
        }

        /*public void OnGet()
           {
         }*/
        public async Task<IActionResult> OnPostAsync()
        {
            // Obtain values for the <select> list in web form
            PizzaList = new SelectList(_context.Pizza, "PizzaName", "PizzaName");

            if (!ModelState.IsValid)  // validate user input
            {
                return Page();
            }

            var Pizza = await _context.Pizza.FirstOrDefaultAsync(m => m.PizzaName == PizzaPurchase.PizzaName);
            ViewData["TotalPrice"] = Pizza.Price * PizzaPurchase.PizzaCount;
            return Page();
        }
    }
}
