using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using ThreeSistersHotel.Models;

namespace ThreeSistersHotel.Pages.Customers
{
    [Authorize(Roles = "customers")]
    public class SearchRoomsModel : PageModel
    {
        private readonly ThreeSistersHotel.Data.ApplicationDbContext _context;

        public SearchRoomsModel(ThreeSistersHotel.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }


        [BindProperty]
        public SearchRoom searchRoomInput { get; set; }
        public IList<Room> TheRooms { get; set; }


        public async Task<IActionResult> OnPostAsync()
        {

            if (!ModelState.IsValid)
            {
                return Page();
            }


            //check for inconsistencies in date
            int daysDiff = (searchRoomInput.CheckOut - searchRoomInput.CheckIn).Days;

            if (daysDiff <= 0)
            {
                ViewData["DaysDiff"] = 1;
                return Page();
            }

            DateTime today = DateTime.Today;
            int daysDiff2 = (searchRoomInput.CheckIn - today).Days;

            if (daysDiff2 < 0)
            {
                ViewData["DaysDiff2"] = 1;
                return Page();
            }

            //prepare SQL paramters
            var bCount = new SqliteParameter("bedCount", searchRoomInput.BedCount);
            var cOutB = new SqliteParameter("checkOutB", searchRoomInput.CheckOut);
            var cInB = new SqliteParameter("checkInB", searchRoomInput.CheckIn);

            //Execute SQL statement
            IQueryable<Room> rooms = _context.Room.FromSqlRaw("SELECT DISTINCT [Room].* FROM [Room] WHERE [Room].BedCount = @bedCount AND [Room].ID NOT IN (SELECT [Room].ID FROM [Room] inner join [Booking] on [Room].ID = [Booking].RoomID WHERE([Booking].CheckIn  < @checkOutB AND @checkInB < [Booking].CheckOut))", bCount, cOutB, cInB);
            TheRooms = await rooms.ToListAsync();

            return Page();
        }
    }

}
