﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeSistersHotel.Models
{
    public class Booking
    {
        // primary key
        public int ID { get; set; }

        // foreign key
        public int RoomID { get; set; }

        // foreign key
        [DataType(DataType.EmailAddress)]
        public string CustomerEmail { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Check in")]
        public DateTime CheckIn { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Check out")]
        public DateTime CheckOut { get; set; }

        public decimal Cost{ get; set; }

        // Navigation properties
        [Display(Name = "Room number")]
        public Room TheRoom { get; set; }
        [Display(Name = "Customer")]
        public Customer TheCustomer { get; set; }


    }
}
