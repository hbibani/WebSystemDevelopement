﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class Customer
    {
        public int customerID { get; set; }

        [Required]
        [MinLength(2), MaxLength(20)]
        [Display(Name = "Last Name")]
        [RegularExpression(@"^[a-zA-Z'-]*$", ErrorMessage ="Please enter a valid last name with either letters, apostrophe or hyphen.")]
        public string FamilyName { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-Z'-]*$", ErrorMessage = "Please enter a valid first name with either letters, apostrophe or hyphen.")]
        [MinLength(2), MaxLength(20)]
        [Display(Name = "Given Name")]
        public string GivenName { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Date of Birth")]
        public DateTime BirthDate { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^(04\d{2}\s\d{3}\s\d{3})$", ErrorMessage = "Please enter a 10 digit number with spaces in position 5 and 9 04XX XXX XXX")]
        public string Mobile { get; set; }

        [Required]
        [DataType(DataType.PostalCode)]
        [Display(Name = "Postal Code")]
        [RegularExpression(@"^[0-8][0-9]{3}$", ErrorMessage = "Please enter a 4 digit number not starting with a 9")]
        public string PostCode { get; set; }

    }
}
