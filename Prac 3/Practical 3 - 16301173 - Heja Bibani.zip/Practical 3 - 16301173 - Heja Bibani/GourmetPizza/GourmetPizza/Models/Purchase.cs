﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class Purchase
    {

 
        public int ID { get; set; }

        //foreign key
        public int PizzaID { get; set; }

        // foreign key
        [Required]
        [DataType(DataType.EmailAddress)]
        //[EmailAddress], implied above
        public string CustomerEmail { get; set; }

        [Required]
        [Display(Name = "Number of Pizzas")]
        [Range(1, 80)]
        public int PizzaCount { get; set; }

        [Range(1.00, 1000.00)]
        [Display(Name = "Total Cost")]
        public decimal TotalCost { get; set; }

        // Navigation properties
        [Display(Name = "The Pizza")]
        public Pizza ThePizza { get; set; }

        [Display(Name = "The Customer")]
        public Customer TheCustomer { get; set; }

    }
}
