using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ThreeSistersHotel.Models;

namespace ThreeSistersHotel.Pages.Customers
{
    [Authorize(Roles = "customers")]
    public class MyBookingsModel : PageModel
    {
        private readonly ThreeSistersHotel.Data.ApplicationDbContext _context;

        public MyBookingsModel(ThreeSistersHotel.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Booking> Booking { get; set; }

        public async Task OnGetAsync(string sortOrder)
        {

            if (String.IsNullOrEmpty(sortOrder))
            {
                // When the Index page is loaded for the first time, the sortOrder is empty.
                // By default, the movies should be displayed in the order of title_asc.
                sortOrder = "title_asc";
            }


            // retrieve the logged-in user's email
            // need to add "using System.Security.Claims;"
            string _email = User.FindFirst(ClaimTypes.Name).Value;
            Customer customer = await _context.Customer.FirstOrDefaultAsync(m => m.Email == _email);

            var bookings = (IQueryable<Booking>)_context.Booking;

            // Sort the movies by specified order
            switch (sortOrder)
            {
                case "title_asc":
                    bookings = bookings.Include(b => b.TheCustomer).Include(b => b.TheRoom).Where(m => m.CustomerEmail == _email).OrderBy(m => m.CheckIn);
                    break;
                case "title_desc":
                    bookings = bookings.Include(b => b.TheCustomer).Include(b => b.TheRoom).Where(m => m.CustomerEmail == _email).OrderByDescending(m => m.CheckIn);
                    break;
                case "price_asc":
                    bookings = bookings.Include(b => b.TheCustomer).Include(b => b.TheRoom).Where(m => m.CustomerEmail == _email).OrderBy(m => (double)m.Cost);
                    break;
                case "price_desc":
                    bookings = bookings.Include(b => b.TheCustomer).Include(b => b.TheRoom).Where(m => m.CustomerEmail == _email).OrderByDescending(m => (double)m.Cost);
                    break;
            }

            // Deciding the query string (sortOrder=xxx) to include in the heading links
            // for Title and Price respectively.
            // They specify the next display order if a heading link is clicked. 
            // Store them in ViewData dictionary to pass them to View.
            ViewData["NextTitleOrder"] = sortOrder != "title_asc" ? "title_asc" : "title_desc";
            ViewData["NextPriceOrder"] = sortOrder != "price_asc" ? "price_asc" : "price_desc";

            Booking = await bookings.AsNoTracking().ToListAsync();
        }
    }
}
