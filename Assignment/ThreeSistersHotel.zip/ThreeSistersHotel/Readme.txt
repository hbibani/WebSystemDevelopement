
Student Information:
Esho Youkhanna		18082627	18082627@student.westernsydney.edu.au
Heja Bibani		16301173	16301173@student.westernsydney.edu.au
Rijo Mathew Kalarickal	19485788	19485788@student.westernsydney.edu.au


Usernames and Password: 

[The following password is used for all users]
Password: P@ssw0rd 

bob@outlook.com	Bibani		Bob	2164
1@outlook.com	Smith		Thomas	2164
2@outlook.com	Thompson	Sam	2164
3@outlook.com	Bigzbee		Justin	2122
4@outlook.com	Lokland		Luke	2155
6@outlook	Sujik		Soham	2155
7@outlook.com	Min		Suk	2542
8@outlook.com	Monte		Eman	2522
9@outlook.com	Meely		Nathan	2164
10@outlook.com	Kline		Tammy	2122
11@outlook.com	Heja		Bibani	2164
