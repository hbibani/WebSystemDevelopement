﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class PizzaStatistic
    {
        [Display(Name = "Pizza Count")]
        public int PizzaCount { get; set; }

        [Display(Name = "Purchase Count")]
        public int PurchaseCount { get; set; }
    }
}
