using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GourmetPizza.Pages.PizzaTest
{
    public class PurchaseModel : PageModel
    {
        public void OnGet(int PizzaType, int PizzaCount=1)
        {

            double total = 0.00;
            string name = "";
            switch (PizzaType)
            {
                case 1:
                    total = PizzaCount * 10.50;
                    name = "BBQ Beef";
                    break;
                case 2:
                    total = PizzaCount * 8.50;
                    name = "Chicken Pineapple";
                    break;
                case 3:
                    total = PizzaCount * 9.00;
                    name = "Pepperoni Feast";
                    break;
                case 4:
                    total = PizzaCount * 7.00;
                    name = "Vegetarian";
                    break;
            }

            ViewData["Name"] = name;
            ViewData["Total"] = total;

        }
    }
}
