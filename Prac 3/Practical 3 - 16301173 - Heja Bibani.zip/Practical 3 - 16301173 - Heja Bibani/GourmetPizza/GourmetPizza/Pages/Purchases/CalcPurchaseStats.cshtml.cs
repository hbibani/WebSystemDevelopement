using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GourmetPizza.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace GourmetPizza.Pages.Purchases
{
    [Authorize(Roles = "customers")]
    public class CalcPurchaseStatsModel : PageModel
    {
     
        private readonly GourmetPizza.Data.ApplicationDbContext _context;

        public CalcPurchaseStatsModel(GourmetPizza.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<PizzaStatistic> PizzaStats { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // divide the movies into groups by genre
            var pizzaGroups = _context.Purchase.GroupBy(p => p.PizzaCount);

            // for each group, get its genre value and the number of movies in this group
            PizzaStats = await pizzaGroups.Select(g => new PizzaStatistic { PizzaCount = g.Key, PurchaseCount = g.Count() }).ToListAsync();

            return Page();
        }

    }
}
