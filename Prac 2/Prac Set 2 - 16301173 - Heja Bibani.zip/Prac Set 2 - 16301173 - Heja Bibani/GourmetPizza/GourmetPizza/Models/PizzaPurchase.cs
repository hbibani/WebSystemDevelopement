﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class PizzaPurchase
    {
        [Required]
        [Display(Name = "Pizza")]
        public string PizzaName { get; set; }

        [Required]
        [Display(Name = "Number of Pizzas")]
        [Range(1, 10)]
        public int PizzaCount { get; set; }

        [Required]
        [Display(Name ="Credit Card Details")]
        [RegularExpression(@"^[0-9]{16}$", ErrorMessage = "Please enter a 16 digit credit-card number")]
        public string CreditCard { get; set; }
    }
}
