﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GourmetPizza.Models
{
    public class Pizza
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_ ]*$", ErrorMessage = "Letters, number or underscore only.")]
        [MinLength(3), MaxLength(20)]
        public string PizzaName { get; set; }

        [Display(Name = "Price Each")]
        [DataType(DataType.Currency)]
        [Range(5,20)]
        public decimal Price { get; set; }

        //Navigation
        public ICollection<Purchase> ThePurchases { get; set; }
    }
}
